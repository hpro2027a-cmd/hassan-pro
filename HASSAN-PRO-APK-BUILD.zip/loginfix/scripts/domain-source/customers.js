(function(){
  "use strict";
  const {cloneState,commitDraft,assertState}=window.HassanDomain.helpers;
  const customers={
    upsert(state,input,existing,deps){
      assertState(state);
      const {uid,now}=deps;
      const draft=cloneState(state);
      const name=String(input.name||"").trim();
      const phone=String(input.phone||"").trim();
      const address=String(input.address||"").trim();
      if(!name||!phone) throw new Error("أدخل اسم العميل ورقم الهاتف");
      if(draft.customers.some(v=>String(v.id)!==String(existing?.id||"")&&String(v.phone||"").trim()===phone)) throw new Error("رقم الهاتف مرتبط بعميل آخر");
      const customer=existing?{...existing}:{id:uid(),createdAt:now()};
      Object.assign(customer,{name,phone,address,updatedAt:now()});
      draft.customers=existing?draft.customers.map(v=>String(v.id)===String(customer.id)?customer:v):[customer,...draft.customers];
      commitDraft(state,draft);
      return {entity:customer,audit:{action:existing?"تعديل":"إضافة",entity:"عميل",id:customer.id,details:(existing?"تعديل ":"إضافة ")+name}};
    },
    remove(state,id,deps){
      assertState(state);
      const draft=cloneState(state);
      const customer=draft.customers.find(v=>String(v.id)===String(id));
      if(!customer) throw new Error("العميل غير موجود");
      const linked=(draft.sales||[]).some(v=>String(v.customerId||"")===String(id))||(draft.maintenance||[]).some(v=>String(v.customerId||"")===String(id)||(String(v.customerName||"").trim()===String(customer.name||"").trim()&&String(v.customerPhone||"").trim()===String(customer.phone||"").trim()));
      if(linked) throw new Error("لا يمكن حذف عميل مرتبط بفواتير أو صيانة؛ عدّل بياناته بدل حذفه");
      draft.customers=draft.customers.filter(v=>String(v.id)!==String(id));
      commitDraft(state,draft);
      return {entity:customer,audit:{action:"حذف",entity:"عميل",id:customer.id,details:"حذف "+customer.name}};
    }
  };
  window.HassanDomain.customers=customers;
})();
