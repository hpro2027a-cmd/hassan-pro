(function(){
  "use strict";
  const {cloneState,commitDraft,assertState}=window.HassanDomain.helpers;
  const suppliers={
    upsert(state,input,existing,deps){
      assertState(state);const {uid,now}=deps,draft=cloneState(state);const name=String(input.name||"").trim(),phone=String(input.phone||"").trim(),address=String(input.address||"").trim();
      if(!name||!phone)throw new Error("أدخل اسم المورد ورقم الهاتف");
      if(draft.suppliers.some(v=>String(v.id)!==String(existing?.id||"")&&String(v.phone||"").trim()===phone))throw new Error("رقم الهاتف مرتبط بمورد آخر");
      const supplier=existing?{...existing}:{id:uid(),createdAt:now()};Object.assign(supplier,{name,phone,address,updatedAt:now()});
      draft.suppliers=existing?draft.suppliers.map(v=>String(v.id)===String(supplier.id)?supplier:v):[supplier,...draft.suppliers];commitDraft(state,draft);
      return {entity:supplier,audit:{action:existing?"تعديل":"إضافة",entity:"مورد",id:supplier.id,details:(existing?"تعديل ":"إضافة ")+name}};
    },
    pay(state,id,amount,deps){
      assertState(state);
      const {uid,now,safeAmount,visibleByWarehouse}=deps;
      const draft=cloneState(state);
      const supplier=draft.suppliers.find(v=>String(v.id)===String(id));
      if(!supplier) throw new Error("المورد غير موجود");
      const payment=safeAmount(amount);
      if(payment<=0) throw new Error("أدخل مبلغ دفع صحيح");
      const devices=visibleByWarehouse(draft.devices).filter(v=>String(v.supplierId||"")===String(id)&&Number(v.supplierDue||0)>0);
      const purchases=visibleByWarehouse(draft.supplierPurchases).filter(v=>String(v.supplierId||"")===String(id)&&Number(v.due||0)>0);
      const due=devices.reduce((n,v)=>n+Math.max(0,Number(v.supplierDue||0)),0)+purchases.reduce((n,v)=>n+Math.max(0,Number(v.due||0)),0);
      if(payment>due) throw new Error("مبلغ الدفع أكبر من مستحق المورد");
      let remain=payment;
      for(const device of devices){
        if(remain<=0) break;
        const take=Math.min(remain,Number(device.supplierDue||0));
        device.supplierPaid=Number(device.supplierPaid||0)+take;
        device.supplierDue=Math.max(0,Number(device.cost||device.totalCost||0)-device.supplierPaid);
        draft.cash.push({id:uid(),type:"out",amount:take,section:"supplier",warehouseId:device.warehouseId||"main",refType:"supplierPayment",refId:supplier.id,deviceId:device.id,reason:"دفع للمورد "+supplier.name+" — "+device.name,date:now()});
        remain-=take;
      }
      for(const purchase of purchases){
        if(remain<=0) break;
        const take=Math.min(remain,Number(purchase.due||0));
        purchase.paid=Number(purchase.paid||0)+take;
        purchase.due=Math.max(0,Number(purchase.totalCost||0)-purchase.paid);
        draft.cash.push({id:uid(),type:"out",amount:take,section:"supplier",warehouseId:purchase.warehouseId||"main",refType:"supplierPayment",refId:supplier.id,supplierPurchaseId:purchase.id,maintenanceId:purchase.maintenanceId,reason:"دفع للمورد "+supplier.name+" — شراء صيانة",date:now()});
        remain-=take;
      }
      if(remain>0) throw new Error("تعذر توزيع كامل المبلغ على مستحقات المورد");
      commitDraft(state,draft);
      return {entity:supplier,audit:{action:"دفع",entity:"مورد",id:supplier.id,details:"دفع "+payment}};
    },
    remove(state,id){
      assertState(state);
      const draft=cloneState(state);
      const supplier=draft.suppliers.find(v=>String(v.id)===String(id));
      if(!supplier) throw new Error("المورد غير موجود");
      if((draft.devices||[]).some(v=>String(v.supplierId||"")===String(id))||(draft.supplierPurchases||[]).some(v=>String(v.supplierId||"")===String(id))) throw new Error("لا يمكن حذف مورد مرتبط بمشتريات أو أجهزة؛ عدّل بياناته بدل حذفه");
      draft.suppliers=draft.suppliers.filter(v=>String(v.id)!==String(id));
      commitDraft(state,draft);
      return {entity:supplier,audit:{action:"حذف",entity:"مورد",id:supplier.id,details:"حذف "+supplier.name}};
    }
  };
  window.HassanDomain.suppliers=suppliers;
})();
