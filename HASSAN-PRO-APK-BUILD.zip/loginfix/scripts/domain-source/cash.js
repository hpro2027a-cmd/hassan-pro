(function(){
  "use strict";
  const {cloneState,commitDraft,assertState}=window.HassanDomain.helpers;
  const cash={
    add(state,input,deps){
      assertState(state); const {uid,now,safeAmount}=deps, draft=cloneState(state), amount=safeAmount(input.amount);
      if(amount<=0) throw new Error("أدخل مبلغًا صحيحًا");
      const type=String(input.type||"in")==="out"?"out":"in", warehouseId=String(input.warehouseId||"main");
      const movement={id:uid(),type,amount,section:String(input.section||"expense"),warehouseId,reason:String(input.reason||"حركة يدوية").trim()||"حركة يدوية",date:now()};
      draft.cash.push(movement); commitDraft(state,draft); return {entity:movement,audit:{action:type==="in"?"قبض":"صرف",entity:"حركة خزنة",id:movement.id,details:movement.reason}};
    },
    extra(state,input,deps){
      return this.add(state,{...input,type:"in",section:"extra",reason:String(input.reason||"رصيد إضافي")},deps);
    }
  };
  window.HassanDomain.cash=cash;
})();