(function(){
  "use strict";
  const {cloneState,commitDraft,assertState,recordInventoryMovement}=window.HassanDomain.helpers;
  const warehouses={
    transfer(state,input,deps){
      assertState(state);
      const {uid,now,masterKey}=deps, draft=cloneState(state);
      const from=String(input.fromWarehouseId||"main"), to=String(input.toWarehouseId||"main"), qty=Math.max(1,Math.floor(Number(input.qty)||0));
      if(!from||!to||from===to) throw new Error("اختر مخزنين مختلفين");
      const source=draft.inventory.find(v=>String(v.id)===String(input.productId)&&String(v.warehouseId||"main")===from);
      if(!source) throw new Error("المنتج غير موجود في المخزن المصدر");
      if(Number(source.qty||0)<qty) throw new Error("الكمية أكبر من المتاح في المخزن المصدر");
      source.qty-=qty;
      let dest=draft.inventory.find(v=>String(v.productMasterId||"")===String(source.productMasterId||"")&&String(v.warehouseId||"main")===to);
      if(!dest&&source.sku) dest=draft.inventory.find(v=>String(v.sku||"")===String(source.sku||"")&&String(v.warehouseId||"main")===to);
      if(!dest){dest={...source,id:uid(),warehouseId:to,qty:0};draft.inventory.push(dest)}
      dest.qty=Number(dest.qty||0)+qty;
      dest.updatedAt=now();
      const transfer={id:uid(),productId:source.id,productMasterId:source.productMasterId||masterKey(source),productSku:source.sku||"",productName:source.name||source.model||"منتج",productBrand:source.brand||"",productCategory:source.category||source.type||"",fromWarehouseId:from,toWarehouseId:to,qty,date:now(),status:"تم التحويل"};
      draft.transfers=Array.isArray(draft.transfers)?draft.transfers:[];
      draft.transfers.push(transfer);
      recordInventoryMovement(draft,{productId:source.id,warehouseId:from,qty,direction:"out",sourceType:"transfer",sourceId:transfer.id,reason:"تحويل إلى مخزن "+to},deps);
      recordInventoryMovement(draft,{productId:dest.id,warehouseId:to,qty,direction:"in",sourceType:"transfer",sourceId:transfer.id,reason:"استلام تحويل من مخزن "+from},deps);
      commitDraft(state,draft);
      return {entity:transfer,audit:{action:"تحويل",entity:"مخزون",id:transfer.id,details:"تحويل "+transfer.productName+" | النوع: "+(transfer.productCategory||"غير محدد")+" | من "+from+" إلى "+to+" × "+qty}};
    }
  };
  window.HassanDomain.warehouses=warehouses;
})();