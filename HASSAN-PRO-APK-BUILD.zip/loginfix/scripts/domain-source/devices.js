(function(){
  "use strict";
  const {cloneState,commitDraft,assertState}=window.HassanDomain.helpers;
  const devices={
    savePurchase(state,input,deps){
      assertState(state); const {uid,now,safeAmount}=deps, draft=cloneState(state), existing=input.existing||null;
      const device={...(existing||{}),...input.device};
      if(!device.id) device.id=uid();
      if(!device.status) device.status="available";
      const imei=String(device.imei||"").trim(),imei2=String(device.imei2||"").trim(),serial=String(device.serialNumber||"").trim();
      if(imei&&draft.devices.some(v=>String(v.id)!==String(device.id)&&String(v.imei||"").trim()===imei)) throw new Error("IMEI مستخدم بالفعل في جهاز آخر");
      if(imei2&&draft.devices.some(v=>String(v.id)!==String(device.id)&&String(v.imei2||"").trim()===imei2)) throw new Error("IMEI 2 مستخدم بالفعل في جهاز آخر");
      if(serial&&draft.devices.some(v=>String(v.id)!==String(device.id)&&String(v.serialNumber||"").trim()===serial)) throw new Error("Serial Number مستخدم بالفعل في جهاز آخر");
      const oldPaid=safeAmount(existing?.supplierPaid), newPaid=safeAmount(device.supplierPaid), delta=newPaid-oldPaid;
      device.supplierDue=Math.max(0,safeAmount(device.totalCost??device.cost)-newPaid);
      device.purchaseCashRecorded=newPaid>0;
      draft.devices=existing?draft.devices.map(v=>String(v.id)===String(device.id)?device:v):[device,...draft.devices];
      if(delta>0) draft.cash.push({id:uid(),type:"out",amount:delta,section:"devicePurchase",warehouseId:device.warehouseId||"main",refType:"devicePurchase",refId:device.id,reason:existing?"زيادة مدفوع شراء "+device.name:"شراء جهاز "+device.name,date:now()});
      if(delta<0) draft.cash.push({id:uid(),type:"in",amount:-delta,section:"devicePurchase",warehouseId:device.warehouseId||"main",refType:"devicePurchase",refId:device.id,reason:"عكس تعديل شراء "+device.name,date:now()});
      commitDraft(state,draft); return {entity:device,audit:{action:existing?"تعديل":"شراء",entity:"جهاز",id:device.id,details:(existing?"تعديل شراء ":"شراء ")+device.name}};
    }
  };
  window.HassanDomain.devices=devices;
})();