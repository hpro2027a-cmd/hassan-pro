(function(){
  "use strict";
  const {cloneState,commitDraft,assertState}=window.HassanDomain.helpers;
  const deviceActions={
    sell(state,id,input,deps){
      assertState(state); const {uid,now,safeAmount}=deps; const draft=cloneState(state); const device=draft.devices.find(v=>String(v.id)===String(id));
      if(!device||device.status==="sold") throw new Error("الجهاز غير متاح للبيع");
      const price=safeAmount(input.price),discount=Math.min(price,safeAmount(input.discount)),total=Math.max(0,price-discount),paid=safeAmount(input.paid),saleTax=safeAmount(input.saleTax),expenses=safeAmount(input.saleExpenses);
      if(price<=0||paid>total) throw new Error("أدخل سعر بيع صحيح وتأكد أن المدفوع لا يتجاوز الإجمالي");
      const paymentMethod=String(input.paymentMethod||"cash")==="wallet"?"wallet":"cash",walletNumber=String(input.walletNumber||"").trim();
      if(paymentMethod==="wallet"&&!walletNumber) throw new Error("أدخل رقم المحفظة المحول له المبلغ");
      const buyerName=String(input.buyerName||"").trim(),buyerPhone=String(input.buyerPhone||"").trim(),buyerAddress=String(input.buyerAddress||"").trim();
      if(!buyerName) throw new Error("أدخل اسم العميل");
      const existingCustomer=buyerPhone?draft.customers.find(c=>String(c.phone||"").trim()===buyerPhone):null;
      if(existingCustomer){existingCustomer.name=buyerName;existingCustomer.address=buyerAddress||existingCustomer.address||"";device.customerId=existingCustomer.id}
      else if(buyerPhone){device.customerId=uid();draft.customers.unshift({id:device.customerId,name:buyerName,phone:buyerPhone,address:buyerAddress,createdAt:now()})}
      else device.customerId="";
      const oldPaid=safeAmount(device.salePaid);
      Object.assign(device,{status:"sold",saleReturned:false,saleId:String(input.saleId||device.saleId||("SAL-"+new Date().getFullYear()+"-"+String(draft.devices.filter(v=>v.saleId).length+1).padStart(6,"0"))),salePrice:price,saleDiscount:discount,saleTotal:total,salePaid:paid,saleDue:Math.max(0,total-paid),paymentMethod,walletNumber:paymentMethod==="wallet"?walletNumber:"",saleEmployeeId:String(input.saleEmployeeId||""),saleTax,saleExpenses:expenses,warranty:String(input.warranty||"").trim(),saleNotes:String(input.saleNotes||"").trim(),buyerName,buyerPhone,buyerAddress,saleDate:now(),netProfit:total-(safeAmount(device.totalCost??device.cost)+saleTax+expenses)});
      const delta=paid-oldPaid;
      if(delta>0) draft.cash.push({id:uid(),type:"in",amount:delta,section:"sales",warehouseId:device.warehouseId||"main",refType:"deviceSale",refId:device.id,customerId:device.customerId||"",reason:"بيع/تحصيل جهاز "+device.name+" — "+device.saleId,date:now()});
      if(delta<0) draft.cash.push({id:uid(),type:"out",amount:-delta,section:"sales",warehouseId:device.warehouseId||"main",refType:"deviceSaleReturn",refId:device.id,customerId:device.customerId||"",reason:"عكس تعديل قبض بيع جهاز "+device.name,date:now()});
      commitDraft(state,draft); return {entity:device,audit:{action:"بيع",entity:"جهاز",id:device.id,details:"Sale ID: "+device.saleId+" | صافي الربح: "+device.netProfit}};
    },
    collect(state,id,amount,deps){
      assertState(state); const {uid,now,safeAmount}=deps,draft=cloneState(state),device=draft.devices.find(v=>String(v.id)===String(id));
      if(!device||device.status!=="sold") throw new Error("الجهاز غير مباع"); const due=Math.max(0,Number(device.saleDue||0)),payment=safeAmount(amount);
      if(due<=0||payment<=0||payment>due) throw new Error("أدخل مبلغ تحصيل صحيح");
      device.salePaid=Number(device.salePaid||0)+payment;device.saleDue=Math.max(0,Number(device.salePrice||device.saleTotal||0)-device.salePaid);
      draft.cash.push({id:uid(),type:"in",amount:payment,section:"sales",warehouseId:device.warehouseId||"main",refType:"deviceSale",refId:device.id,customerId:device.customerId||"",reason:"تحصيل فاتورة بيع جهاز "+device.name,date:now()});
      commitDraft(state,draft);return {entity:device,audit:{action:"تحصيل",entity:"بيع جهاز",id:device.id,details:"تحصيل "+payment}};
    },
    restore(state,id,deps){
      assertState(state); const {uid,now,safeAmount}=deps,draft=cloneState(state),device=draft.devices.find(v=>String(v.id)===String(id));
      if(!device||device.status!=="sold"||device.saleReturned) throw new Error("الجهاز غير موجود ضمن الأجهزة المباعة");
      const alreadyReversed=draft.cash.some(c=>String(c.refType||"")==="deviceSaleReturn"&&String(c.refId||"")===String(device.id));
      if(!alreadyReversed){const paid=Math.max(0,safeAmount(device.salePaid));if(paid>0)draft.cash.push({id:uid(),type:"out",amount:paid,section:"sales",warehouseId:device.warehouseId||"main",refType:"deviceSaleReturn",refId:device.id,customerId:device.customerId||"",reason:"عكس استرجاع بيع "+device.name,date:now()})}
      device.status="available";device.saleReturned=false;device.returnedFromSale=true;device.saleCashRecorded=false;device.returnedAt=now();commitDraft(state,draft);
      return {entity:device,audit:{action:"استرجاع بيع",entity:"جهاز",id:device.id,details:"استرجاع بيع "+device.name+" | عكس المقبوض: "+safeAmount(device.salePaid)}};
    },
    remove(state,id,deps){
      assertState(state); const {uid,now,safeAmount}=deps,draft=cloneState(state),device=draft.devices.find(v=>String(v.id)===String(id));
      if(!device) throw new Error("الجهاز غير موجود"); const oldCash=draft.cash||[];
      const legacyPurchase=oldCash.filter(c=>!c.refId&&c.section==="devicePurchase"&&String(c.reason||"")===`شراء جهاز ${device.name}`&&Number(c.amount||0)===Number(device.supplierPaid||0));
      const legacySale=oldCash.filter(c=>!c.refId&&c.section==="sales"&&String(c.reason||"")===`بيع جهاز ${device.name}`&&Number(c.amount||0)===Number(device.salePrice||0));
      const removeIds=new Set(oldCash.filter(c=>String(c.refId||"")===String(device.id)||String(c.deviceId||"")===String(device.id)).map(c=>c.id));[...legacyPurchase,...legacySale].forEach(c=>removeIds.add(c.id));
      const linked=oldCash.filter(c=>removeIds.has(c.id));draft.cash=oldCash.filter(c=>!removeIds.has(c.id));
      const cashIn=linked.filter(c=>c.type==="in").reduce((n,c)=>n+safeAmount(c.amount),0),cashOut=linked.filter(c=>c.type==="out").reduce((n,c)=>n+safeAmount(c.amount),0);
      if(cashIn>0)draft.cash.push({id:uid(),type:"out",amount:cashIn,section:"sales",warehouseId:device.warehouseId||"main",refType:"device-delete-reversal",refId:device.id,reason:"عكس قبض حذف الجهاز "+device.name,date:now()});
      if(cashOut>0)draft.cash.push({id:uid(),type:"in",amount:cashOut,section:"devicePurchase",warehouseId:device.warehouseId||"main",refType:"device-delete-reversal",refId:device.id,reason:"عكس صرف حذف الجهاز "+device.name,date:now()});
      draft.devices=draft.devices.filter(v=>String(v.id)!==String(id));commitDraft(state,draft);
      return {entity:device,photoRefs:Array.isArray(device.photoRefs)?device.photoRefs:[],audit:{action:"حذف",entity:"جهاز",id:device.id,details:"حذف "+device.name+" | عكس المقبوض والمدفوع: "+cashIn+" / "+cashOut}};
    }
  };
  window.HassanDomain.deviceActions=deviceActions;
})();
