(function(){
  "use strict";
  const {cloneState,commitDraft,assertState,recordInventoryMovement}=window.HassanDomain.helpers;

  const operations={
    returnSale(state,saleId,input,deps){
      assertState(state);
      const {uid,now,safeAmount}=deps;
      const draft=cloneState(state);
      const sale=draft.sales.find(v=>String(v.id)===String(saleId));
      if(!sale) throw new Error("فاتورة البيع غير موجودة");
      const soldQty=Math.max(0,Math.floor(Number(sale.qty)||0));
      const alreadyReturned=Math.max(0,Math.floor(Number(sale.returnedQty)||0));
      const available=soldQty-alreadyReturned;
      const qty=Math.max(1,Math.floor(Number(input.qty)||0));
      if(qty>available) throw new Error("كمية المرتجع أكبر من الكمية المتبقية من الفاتورة");
      const amount=safeAmount(input.amount);
      if(amount<=0) throw new Error("أدخل قيمة مرتجع صحيحة");
      const remainingTotal=Math.max(0,safeAmount(sale.total)-safeAmount(sale.returnedAmount));
      if(amount>remainingTotal) throw new Error("قيمة المرتجع أكبر من المتبقي من قيمة الفاتورة");
      const refund=safeAmount(input.refundAmount);
      if(refund>safeAmount(sale.paid)-safeAmount(sale.refundedAmount)) throw new Error("مبلغ الرد أكبر من المبلغ المقبوض والمتاح للرد");
      if(refund>amount) throw new Error("مبلغ الرد لا يمكن أن يتجاوز قيمة المرتجع");
      const nextTotal=Math.max(0,safeAmount(sale.total)-amount);
      const nextPaid=Math.max(0,safeAmount(sale.paid)-refund);
      if(nextPaid>nextTotal) throw new Error("المرتجع سيترك مبلغًا محصلًا أكبر من إجمالي الفاتورة؛ سجل قيمة رد مساوية للجزء الزائد أو اترك رصيدًا للعميل عبر كشف الحساب");

      const product=sale.productId?draft.inventory.find(v=>String(v.id)===String(sale.productId)&&String(v.warehouseId||"main")===String(sale.warehouseId||"main")):null;
      if(sale.productId&&!product) throw new Error("منتج الفاتورة غير موجود في المخزن");
      if(product){
        product.qty=Number(product.qty||0)+qty;
        recordInventoryMovement(draft,{
          productId:product.id,warehouseId:product.warehouseId||sale.warehouseId||"main",qty,
          direction:"in",sourceType:"sale-return",sourceId:sale.id,reason:"مرتجع فاتورة بيع "+sale.no
        },deps);
        product.updatedAt=now();
      }

      const returnRecord={
        id:uid(),saleId:sale.id,saleNo:sale.no,productId:sale.productId||"",warehouseId:sale.warehouseId||"main",
        qty,amount,refundAmount:refund,reason:String(input.reason||"").trim(),date:now(),userId:String(input.userId||""),
        status:"completed"
      };
      draft.salesReturns=Array.isArray(draft.salesReturns)?draft.salesReturns:[];
      draft.salesReturns.unshift(returnRecord);
      sale.returnedQty=alreadyReturned+qty;
      sale.returnedAmount=safeAmount(sale.returnedAmount)+amount;
      sale.refundedAmount=safeAmount(sale.refundedAmount)+refund;
      const unitCost=soldQty>0?safeAmount(sale.costTotal)/soldQty:0;
      sale.costTotal=Math.max(0,safeAmount(sale.costTotal)-(unitCost*qty));
      sale.total=Math.max(0,safeAmount(sale.total)-amount);
      sale.paid=Math.max(0,safeAmount(sale.paid)-refund);
      sale.due=Math.max(0,sale.total-sale.paid);
      sale.status=sale.returnedQty>=soldQty?"returned":"partially-returned";
      sale.updatedAt=now();
      if(refund>0){
        draft.cash.push({id:uid(),type:"out",amount:refund,section:"sales",warehouseId:sale.warehouseId||"main",refType:"sale-return",refId:sale.id,returnId:returnRecord.id,customerId:sale.customerId||"",reason:"رد مرتجع فاتورة "+sale.no,date:now()});
      }
      commitDraft(state,draft);
      return {entity:sale,returnRecord,audit:{action:"مرتجع",entity:"فاتورة بيع",id:sale.id,details:"مرتجع "+sale.no+" × "+qty+" بقيمة "+amount}};
    },

    returnPurchase(state,purchaseId,input,deps){
      assertState(state);
      const {uid,now,safeAmount}=deps;
      const draft=cloneState(state);
      const purchase=draft.supplierPurchases.find(v=>String(v.id)===String(purchaseId));
      if(!purchase) throw new Error("فاتورة الشراء غير موجودة");
      if(purchase.maintenanceId) throw new Error("قطع الصيانة الخارجية تُعالج من أمر الصيانة نفسه");
      const originalQty=Math.max(0,Math.floor(Number(purchase.qty)||0));
      const returnedQty=Math.max(0,Math.floor(Number(purchase.returnedQty)||0));
      const available=originalQty-returnedQty;
      const qty=Math.max(1,Math.floor(Number(input.qty)||0));
      if(qty>available) throw new Error("كمية المرتجع أكبر من الكمية المتبقية من الفاتورة");
      const amount=safeAmount(input.amount);
      if(amount<=0) throw new Error("أدخل قيمة مرتجع صحيحة");
      const maxAmount=Math.max(0,safeAmount(purchase.totalCost)-safeAmount(purchase.returnedAmount));
      if(amount>maxAmount) throw new Error("قيمة المرتجع أكبر من المتبقي من قيمة الفاتورة");
      const refund=safeAmount(input.refundAmount);
      if(refund>safeAmount(purchase.paid)-safeAmount(purchase.refundedAmount)) throw new Error("مبلغ الاسترداد أكبر من المدفوع المتاح");
      if(refund>amount) throw new Error("مبلغ الاسترداد لا يمكن أن يتجاوز قيمة المرتجع");
      const nextTotal=Math.max(0,safeAmount(purchase.totalCost)-amount);
      const nextPaid=Math.max(0,safeAmount(purchase.paid)-refund);
      if(nextPaid>nextTotal) throw new Error("المرتجع سيترك مبلغًا مدفوعًا أكبر من إجمالي الشراء؛ راجع قيمة الاسترداد");

      const product=draft.inventory.find(v=>String(v.id)===String(purchase.productId)&&String(v.warehouseId||"main")===String(purchase.warehouseId||"main"));
      if(!product) throw new Error("منتج فاتورة الشراء غير موجود في المخزن");
      const oldQty=Math.max(0,Number(product.qty||0));
      if(oldQty<qty) throw new Error("الكمية الحالية في المخزن لا تسمح بالمرتجع");
      const oldCost=safeAmount(product.cost);
      product.qty=oldQty-qty;
      if(product.qty>0){
        const remainingValue=Math.max(0,(oldQty*oldCost)-(qty*safeAmount(purchase.unitCost)));
        product.cost=Math.round((remainingValue/product.qty)*100)/100;
      }
      product.updatedAt=now();
      recordInventoryMovement(draft,{
        productId:product.id,warehouseId:product.warehouseId||purchase.warehouseId||"main",qty,
        direction:"out",sourceType:"purchase-return",sourceId:purchase.id,reason:"مرتجع شراء "+purchase.name
      },deps);

      const returnRecord={id:uid(),purchaseId:purchase.id,productId:purchase.productId||"",supplierId:purchase.supplierId||"",warehouseId:purchase.warehouseId||"main",qty,amount,refundAmount:refund,reason:String(input.reason||"").trim(),date:now(),status:"completed"};
      draft.purchaseReturns=Array.isArray(draft.purchaseReturns)?draft.purchaseReturns:[];
      draft.purchaseReturns.unshift(returnRecord);
      purchase.returnedQty=returnedQty+qty;
      purchase.returnedAmount=safeAmount(purchase.returnedAmount)+amount;
      purchase.refundedAmount=safeAmount(purchase.refundedAmount)+refund;
      purchase.totalCost=Math.max(0,safeAmount(purchase.totalCost)-amount);
      purchase.paid=Math.max(0,safeAmount(purchase.paid)-refund);
      purchase.due=Math.max(0,purchase.totalCost-purchase.paid);
      purchase.status=purchase.returnedQty>=originalQty?"returned":"partially-returned";
      purchase.updatedAt=now();
      if(refund>0){
        draft.cash.push({id:uid(),type:"in",amount:refund,section:"supplier",warehouseId:purchase.warehouseId||"main",refType:"purchase-return",refId:purchase.id,returnId:returnRecord.id,supplierId:purchase.supplierId||"",reason:"استرداد مرتجع شراء "+purchase.name,date:now()});
      }
      commitDraft(state,draft);
      return {entity:purchase,returnRecord,audit:{action:"مرتجع",entity:"فاتورة شراء",id:purchase.id,details:"مرتجع "+purchase.name+" × "+qty+" بقيمة "+amount}};
    },

    closeCashDay(state,input,deps){
      assertState(state);
      const {uid,now,safeAmount}=deps;
      const draft=cloneState(state);
      const warehouseId=String(input.warehouseId||"main");
      const date=String(input.date||now()).slice(0,10);
      if(!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("تاريخ الإقفال غير صالح");
      draft.cashClosings=Array.isArray(draft.cashClosings)?draft.cashClosings:[];
      if(draft.cashClosings.some(v=>String(v.warehouseId||"main")===warehouseId&&String(v.date)===date)) throw new Error("تم إقفال هذا المخزن لهذا اليوم بالفعل");
      const movements=draft.cash.filter(v=>String(v.warehouseId||"main")===warehouseId&&String(v.date||"").slice(0,10)<=date);
      const today=movements.filter(v=>String(v.date||"").slice(0,10)===date);
      const before=movements.filter(v=>String(v.date||"").slice(0,10)<date);
      const opening=before.reduce((n,v)=>n+(v.type==="in"?safeAmount(v.amount):-safeAmount(v.amount)),0);
      const inToday=today.filter(v=>v.type==="in").reduce((n,v)=>n+safeAmount(v.amount),0);
      const outToday=today.filter(v=>v.type==="out").reduce((n,v)=>n+safeAmount(v.amount),0);
      const expected=opening+inToday-outToday;
      const actual=safeAmount(input.actualBalance);
      const closing={id:uid(),date,warehouseId,openingBalance:opening,inToday,outToday,expectedBalance:expected,actualBalance:actual,difference:Math.round((actual-expected)*100)/100,note:String(input.note||"").trim(),userId:String(input.userId||""),createdAt:now()};
      draft.cashClosings.unshift(closing);
      commitDraft(state,draft);
      return {entity:closing,audit:{action:"إقفال يومي",entity:"خزنة",id:closing.id,details:"إقفال "+date+" | الفرق "+closing.difference}};
    },

    getCashClosing(state,warehouseId,date){
      return (state.cashClosings||[]).find(v=>String(v.warehouseId||"main")===String(warehouseId||"main")&&String(v.date)===String(date))||null;
    }
  };

  window.HassanDomain.operations=operations;
})();
