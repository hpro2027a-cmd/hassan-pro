(function(){
  "use strict";

  const ENTITY_ARRAYS=[
    "inventory","sales","cash","customers","suppliers","devices","maintenance",
    "supplierPurchases","transfers","audit","inventoryMovements","salesReturns",
    "purchaseReturns","cashClosings"
  ];

  const assertState=state=>{
    if(!state||typeof state!=="object")throw new Error("حالة التطبيق غير صالحة");
    ENTITY_ARRAYS.forEach(key=>{if(!Array.isArray(state[key]))state[key]=[]});
  };

  const commitDraft=(target,draft)=>{
    Object.keys(target).forEach(key=>delete target[key]);
    Object.assign(target,draft);
  };

  const cloneState=state=>JSON.parse(JSON.stringify(state));

  const recordInventoryMovement=(draft,input,deps)=>{
    const {uid,now}=deps;
    const qty=Math.abs(Number(input.qty)||0);
    if(qty<=0)return null;
    const direction=String(input.direction||"").toLowerCase()==="out"?"out":"in";
    const movement={
      id:uid(),productId:String(input.productId||""),warehouseId:String(input.warehouseId||"main"),
      qty,direction,sourceType:String(input.sourceType||"adjustment"),sourceId:String(input.sourceId||""),
      reason:String(input.reason||"تسوية مخزون").trim()||"تسوية مخزون",date:now(),createdAt:now()
    };
    draft.inventoryMovements.unshift(movement);
    return movement;
  };

  const sales={
    save(state,input,existing,deps){
      assertState(state);
      const {uid,now,safeAmount}=deps;
      const existingSale=existing&&String(existing.id||"").trim()?existing:null;
      const draft=cloneState(state);
      const total=safeAmount(input.total),paid=safeAmount(input.paid);
      const qty=Math.max(1,Math.floor(Number(input.qty)||1));
      const warehouseId=String(input.warehouseId||"main"),productId=String(input.productId||"");
      if(!String(input.name||"").trim()||!String(input.phone||"").trim())throw new Error("أكمل بيانات العميل");
      if(total<=0||paid>total)throw new Error("أكمل بيانات المبلغ وتأكد من المدفوع");
      if(existingSale?.returnedQty&&qty<Number(existingSale.returnedQty||0))throw new Error("لا يمكن جعل كمية الفاتورة أقل من الكمية المرتجعة");

      const selected=productId?draft.inventory.find(v=>String(v.id)===productId&&String(v.warehouseId||"main")===warehouseId):null;
      if(productId&&!selected)throw new Error("المنتج غير موجود في المخزن المحدد");
      if(productId){
        let available=Number(selected.qty||0);
        if(existingSale?.productId===productId)available+=Number(existingSale.qty||0)-Number(existingSale.returnedQty||0);
        if(qty>available)throw new Error("الكمية المطلوبة أكبر من المتاح في المخزن المحدد");
      }

      const sale=existingSale?{...existingSale}:{id:uid(),no:"S-"+new Date().getFullYear()+"-"+Date.now()+"-"+uid().slice(-8)};
      if(existingSale?.productId){
        const old=draft.inventory.find(v=>String(v.id)===String(existingSale.productId)&&String(v.warehouseId||"main")===String(existingSale.warehouseId||"main"));
        if(old){const restoreQty=Math.max(0,Number(existingSale.qty||0)-Number(existingSale.returnedQty||0));old.qty=Number(old.qty||0)+restoreQty;if(restoreQty)recordInventoryMovement(draft,{productId:old.id,warehouseId:old.warehouseId,qty:restoreQty,direction:"in",sourceType:"sale-edit-reversal",sourceId:existingSale.id,reason:"عكس كمية قديمة لتعديل فاتورة "+existingSale.no},deps)}
      }
      if(selected){const deductedQty=Math.max(0,qty-Number(existingSale?.returnedQty||0));selected.qty=Number(selected.qty||0)-deductedQty;if(deductedQty)recordInventoryMovement(draft,{productId:selected.id,warehouseId:selected.warehouseId,qty:deductedQty,direction:"out",sourceType:"sale",sourceId:sale.id,reason:"بيع فاتورة "+sale.no},deps)}

      let customerId=String(input.customerId||"");
      if(!customerId){customerId=uid();draft.customers.unshift({id:customerId,name:String(input.name).trim(),phone:String(input.phone).trim(),address:String(input.address||"").trim(),createdAt:now()})}
      else{const customer=draft.customers.find(v=>String(v.id)===customerId);if(customer)Object.assign(customer,{name:String(input.name).trim(),phone:String(input.phone).trim(),address:String(input.address||"").trim()})}

      const unitCost=selected?safeAmount(selected.purchasePrice??selected.cost??0):safeAmount(existingSale?.costTotal&&Number(existingSale.qty)>0?Number(existingSale.costTotal)/Number(existingSale.qty):0);
      Object.assign(sale,{customerId,customer:String(input.name).trim(),phone:String(input.phone).trim(),address:String(input.address||"").trim(),productId,warehouseId,qty,total,paid,due:Math.max(0,total-paid),costTotal:unitCost*qty,note:String(input.note||"").trim(),date:existingSale?.date||now(),status:existingSale?.status==="returned"?"partially-returned":(existingSale?.status||"confirmed"),updatedAt:now()});
      if(!existingSale){sale.returnedQty=0;sale.returnedAmount=0;sale.refundedAmount=0;draft.sales.unshift(sale)}
      else draft.sales=draft.sales.map(v=>String(v.id)===String(existingSale.id)?sale:v);

      const oldPaid=Number(existingSale?.paid||0),delta=paid-oldPaid;
      draft.cash.forEach(c=>{if(String(c.refType||"")==="sale"&&String(c.refId||"")===String(sale.id)){c.warehouseId=warehouseId;c.customerId=customerId}});
      if(delta>0)draft.cash.push({id:uid(),type:"in",amount:delta,section:"sales",warehouseId,refType:"sale",refId:sale.id,customerId,reason:"تحصيل فاتورة "+sale.no,date:now()});
      if(delta<0)draft.cash.push({id:uid(),type:"out",amount:-delta,section:"sales",warehouseId,refType:"sale",refId:sale.id,customerId,reason:"عكس تعديل فاتورة "+sale.no,date:now()});

      commitDraft(state,draft);
      return {entity:sale,audit:{action:existingSale?"تعديل":"إضافة",entity:"فاتورة بيع",id:sale.id,details:(existingSale?"تعديل الفاتورة ":"إضافة الفاتورة ")+sale.no+" | المخزن: "+warehouseId}};
    },

    remove(state,saleId,deps){
      assertState(state);const {uid,now,safeAmount}=deps,draft=cloneState(state),sale=draft.sales.find(v=>String(v.id)===String(saleId));
      if(!sale)throw new Error("فاتورة البيع غير موجودة");
      if(sale.productId){const product=draft.inventory.find(v=>String(v.id)===String(sale.productId)&&String(v.warehouseId||"main")===String(sale.warehouseId||"main"));const qty=Math.max(0,Number(sale.qty||0)-Number(sale.returnedQty||0));if(product&&qty){product.qty=Number(product.qty||0)+qty;recordInventoryMovement(draft,{productId:product.id,warehouseId:product.warehouseId,qty,direction:"in",sourceType:"sale-delete",sourceId:sale.id,reason:"عكس حذف فاتورة "+sale.no},deps)}}
      const linked=draft.cash.filter(c=>String(c.refType||"")==="sale"&&String(c.refId||"")===String(sale.id));
      const totalReversed=linked.reduce((n,c)=>n+safeAmount(c.amount),0);
      draft.cash=draft.cash.filter(c=>!(String(c.refType||"")==="sale"&&String(c.refId||"")===String(sale.id)));
      if(totalReversed>0)draft.cash.push({id:uid(),type:"out",amount:totalReversed,section:"sales",warehouseId:sale.warehouseId||"main",refType:"sale-delete-reversal",refId:sale.id,customerId:sale.customerId||"",reason:"عكس حذف فاتورة "+sale.no,date:now()});
      draft.sales=draft.sales.filter(v=>String(v.id)!==String(saleId));commitDraft(state,draft);
      return {entity:sale,audit:{action:"حذف",entity:"فاتورة بيع",id:sale.id,details:"حذف "+sale.no+" | عكس المقبوض: "+totalReversed}};
    },

    collect(state,saleId,amount,deps){
      assertState(state);const {uid,now,safeAmount}=deps,draft=cloneState(state),sale=draft.sales.find(v=>String(v.id)===String(saleId));
      if(!sale||Number(sale.due||0)<=0)throw new Error("لا يوجد مبلغ متبقٍ");
      const payment=safeAmount(amount);if(payment<=0||payment>Number(sale.due||0))throw new Error("أدخل مبلغ تحصيل صحيح");
      sale.paid=Number(sale.paid||0)+payment;sale.due=Math.max(0,Number(sale.total||0)-sale.paid);sale.updatedAt=now();
      draft.cash.push({id:uid(),type:"in",amount:payment,section:"sales",warehouseId:sale.warehouseId||"main",refType:"sale",refId:sale.id,customerId:sale.customerId||"",reason:"تحصيل فاتورة "+sale.no,date:now()});
      commitDraft(state,draft);return {entity:sale,audit:{action:"تحصيل",entity:"فاتورة بيع",id:sale.id,details:"تحصيل "+payment}};
    }
  };

  const inventory={
    upsert(state,input,existing,deps){
      assertState(state);const {uid,now,masterKey}=deps,draft=cloneState(state);
      const brand=String(input.brand||"").trim(),name=String(input.name||"").trim(),category=String(input.category||"").trim(),warehouseId=String(input.warehouseId||"main"),sku=String(input.sku||"").trim(),barcode=String(input.barcode||"").trim();
      const qty=Math.max(0,Math.floor(Number(input.qty)||0)),minQty=Math.max(0,Math.floor(Number(input.minQty)||0)),cost=Number(input.cost)||0,salePrice=Number(input.salePrice)||0;
      if(!name)throw new Error("أدخل موديل الهاتف");
      const duplicateSku=draft.inventory.find(v=>String(v.id)!==String(existing?.id||"")&&String(v.sku||"").trim().toLowerCase()===sku.toLowerCase()&&String(v.warehouseId||"main")===warehouseId);if(duplicateSku)throw new Error("كود الصنف مستخدم في هذا المخزن");
      if(existing&&String(existing.warehouseId||"main")!==warehouseId){const linkedSale=draft.sales.some(v=>String(v.productId||"")===String(existing.id));const linkedPart=draft.maintenance.some(m=>(m.parts||[]).some(part=>String(part.productId||"")===String(existing.id)));const linkedTransfer=draft.transfers.some(t=>String(t.productId||"")===String(existing.id)||String(t.productMasterId||"")===String(existing.productMasterId||""));if(linkedSale||linkedPart||linkedTransfer)throw new Error("لا يمكن نقل منتج مرتبط بتاريخ مبيعات/صيانة/تحويلات؛ استخدم تحويل المخزون بدل تعديل المخزن.")}
      const duplicateBarcode=draft.inventory.find(v=>String(v.id)!==String(existing?.id||"")&&barcode&&String(v.barcode||"")===barcode);if(duplicateBarcode)throw new Error("الباركود مستخدم بالفعل لمنتج آخر");
      const product=existing?{...existing}:{id:uid(),createdAt:now()};const oldQty=Number(existing?.qty||0);
      Object.assign(product,{brand,name,category,sku,barcode,warehouseId,qty,minQty,cost,salePrice,updatedAt:now(),productMasterId:product.productMasterId||masterKey({sku,name})});
      if(existing)draft.inventory=draft.inventory.map(v=>v.id===existing.id?product:v);else draft.inventory.unshift(product);
      const delta=qty-oldQty;if(delta>0)recordInventoryMovement(draft,{productId:product.id,warehouseId,qty:delta,direction:"in",sourceType:existing?"inventory-adjustment":"opening-balance",sourceId:product.id,reason:existing?"زيادة/تسوية كمية المنتج":"رصيد افتتاحي للمنتج"},deps);if(delta<0)recordInventoryMovement(draft,{productId:product.id,warehouseId,qty:-delta,direction:"out",sourceType:"inventory-adjustment",sourceId:product.id,reason:"تخفيض/تسوية كمية المنتج"},deps);
      commitDraft(state,draft);return {entity:product,audit:{action:existing?"تعديل":"إضافة",entity:"منتج",id:product.id,details:(existing?"تعديل":"إضافة")+" المنتج "+name+" | باركود "+barcode}};
    }
  };

  window.HassanDomain={version:3,helpers:{cloneState,commitDraft,assertState,recordInventoryMovement},sales,inventory};
})();
