(function(){
  "use strict";
  const {cloneState,commitDraft,assertState,recordInventoryMovement}=window.HassanDomain.helpers;
  const purchases={
    product(state,input,deps){
      assertState(state);
      const {uid,now,masterKey,normalizeProductBarcode,generateProductBarcode,generateProductSku,safeAmount}=deps;
      const draft=cloneState(state);
      const supplier=draft.suppliers.find(v=>String(v.id)===String(input.supplierId));
      if(!supplier) throw new Error("اختر المورد أولًا");
      const warehouseId=String(input.warehouseId||"main"), qty=Math.max(1,Math.floor(Number(input.qty)||0));
      const unitCost=safeAmount(input.unitCost), totalCost=unitCost*qty, paid=Math.min(totalCost,safeAmount(input.paid));
      if(totalCost<=0) throw new Error("أدخل سعر شراء صحيح");
      let product=null;
      if(input.existingId){
        product=draft.inventory.find(v=>String(v.id)===String(input.existingId));
        if(!product) throw new Error("المنتج المحدد غير موجود");
        if(String(product.warehouseId||"main")!==warehouseId) throw new Error("اختر نفس مخزن المنتج الموجود أو استخدم منتجًا جديدًا");
        const oldQty=Number(product.qty||0), oldCost=safeAmount(product.cost||0);
        product.qty=oldQty+qty;
        product.cost=((oldQty*oldCost)+totalCost)/Math.max(1,oldQty+qty);
        if(safeAmount(input.salePrice)>0) product.salePrice=safeAmount(input.salePrice);
        product.updatedAt=now();
      }else{
        const name=String(input.name||"").trim(), category=String(input.category||"").trim();
        if(!name||!category) throw new Error("أدخل موديل المنتج ونوعه");
        const rawBarcode=String(input.barcode||"").trim(), barcode=normalizeProductBarcode(rawBarcode)||generateProductBarcode(), sku=generateProductSku(category,warehouseId);
        if(draft.inventory.some(v=>String(v.barcode||"")===barcode)) throw new Error("الباركود مستخدم بالفعل لمنتج آخر");
        product={id:uid(),createdAt:now(),brand:String(input.brand||"").trim(),name,category,sku,barcode,warehouseId,qty,minQty:Math.max(0,Math.floor(Number(input.minQty)||0)),cost:unitCost,salePrice:safeAmount(input.salePrice),updatedAt:now(),productMasterId:masterKey({sku,name})};
        draft.inventory.unshift(product);
      }
      const purchase={id:uid(),source:"supplier",supplierId:supplier.id,supplierName:supplier.name,warehouseId,productId:product.id,name:product.name,qty,unitCost,totalCost,paid,due:Math.max(0,totalCost-paid),date:now()};
      draft.supplierPurchases=Array.isArray(draft.supplierPurchases)?draft.supplierPurchases:[];
      draft.supplierPurchases.push(purchase);
      recordInventoryMovement(draft,{productId:product.id,warehouseId,qty,direction:"in",sourceType:"purchase",sourceId:purchase.id,reason:"شراء من المورد "+supplier.name+" — "+product.name},deps);
      if(paid>0) draft.cash.push({id:uid(),type:"out",amount:paid,section:"supplier",warehouseId,refType:"supplierProductPurchase",refId:supplier.id,supplierPurchaseId:purchase.id,reason:"شراء منتج من المورد "+supplier.name+" — "+product.name,date:now()});
      commitDraft(state,draft);
      return {entity:purchase,product,audit:{action:"شراء",entity:"منتج من مورد",id:purchase.id,details:"شراء "+product.name+" × "+qty+" من "+supplier.name}};
    }
  };
  window.HassanDomain.purchases=purchases;
})();