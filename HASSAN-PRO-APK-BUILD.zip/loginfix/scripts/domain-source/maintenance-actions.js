(function(){
  "use strict";
  const {cloneState,commitDraft,assertState,recordInventoryMovement}=window.HassanDomain.helpers;
  const actions={
    collect(state,id,amount,deps){
      assertState(state);const {uid,now,safeAmount}=deps,draft=cloneState(state),order=draft.maintenance.find(v=>String(v.id)===String(id));
      if(!order)throw new Error("أمر الصيانة غير موجود");const due=Math.max(0,Number(order.total||0)-Number(order.paid||0)),payment=safeAmount(amount);
      if(due<=0||payment<=0||payment>due)throw new Error("أدخل مبلغ تحصيل صحيح");order.paid=Number(order.paid||0)+payment;draft.cash.push({id:uid(),type:"in",amount:payment,section:"maintenance",warehouseId:order.warehouseId||"main",refType:"maintenance",refId:order.id,customerId:order.customerId||"",reason:"تحصيل صيانة "+order.orderNo,date:now()});
      commitDraft(state,draft);return {entity:order,audit:{action:"تحصيل",entity:"صيانة",id:order.id,details:"تحصيل "+payment}};
    },
    changeStatus(state,id,deps){
      assertState(state);const {now,statusLabel}=deps,draft=cloneState(state),order=draft.maintenance.find(v=>String(v.id)===String(id));if(!order)throw new Error("أمر الصيانة غير موجود");
      const statuses=["received","repairing","repaired","ready","delivered"],current=Math.max(0,statuses.indexOf(order.status)),next=statuses[(current+1)%statuses.length];if(next==="delivered"&&Number(order.paid||0)<Number(order.total||0))throw new Error("لا يمكن تسليم الجهاز قبل تحصيل المبلغ كاملًا");
      order.status=next;order.statusLabel=statusLabel(next);order.updatedAt=now();commitDraft(state,draft);return {entity:order,audit:{action:"تغيير حالة",entity:"صيانة",id:order.id,details:order.statusLabel}};
    },
    reject(state,id,deps){
      assertState(state);const {now,statusLabel}=deps,draft=cloneState(state),order=draft.maintenance.find(v=>String(v.id)===String(id));if(!order)throw new Error("أمر الصيانة غير موجود");order.status="rejected";order.statusLabel=statusLabel("rejected");order.updatedAt=now();commitDraft(state,draft);return {entity:order,audit:{action:"رفض",entity:"صيانة",id:order.id,details:"رفض أمر الصيانة"}};
    },
    remove(state,id,deps){
      assertState(state);const {uid,now,safeAmount}=deps,draft=cloneState(state),order=draft.maintenance.find(v=>String(v.id)===String(id));if(!order)throw new Error("أمر الصيانة غير موجود");
      for(const part of order.parts||[]){if(part.source==="warehouse"&&part.productId){const inv=draft.inventory.find(v=>String(v.id)===String(part.productId)&&String(v.warehouseId||"main")===String(part.warehouseId||order.warehouseId||"main"));if(inv){const q=Number(part.qty||0);inv.qty=Number(inv.qty||0)+q;recordInventoryMovement(draft,{productId:inv.id,warehouseId:inv.warehouseId,qty:q,direction:"in",sourceType:"maintenance-delete",sourceId:order.id,reason:"عكس حذف صيانة "+order.orderNo},deps)}}}
      const purchaseIds=new Set((draft.supplierPurchases||[]).filter(q=>String(q.maintenanceId)===String(order.id)).map(q=>String(q.id)));draft.supplierPurchases=(draft.supplierPurchases||[]).filter(q=>String(q.maintenanceId)!==String(order.id));
      const oldCash=draft.cash||[],linked=oldCash.filter(c=>{const direct=String(c.refId||"")===String(order.id)&&["maintenance","maintenance-reversal","maintenancePartExternal"].includes(String(c.refType||""));const supplierPurchase=String(c.refType||"")==="supplierMaintenancePurchase"&&purchaseIds.has(String(c.refId||""));const supplierPayment=String(c.refType||"")==="supplierPayment"&&purchaseIds.has(String(c.supplierPurchaseId||""));const legacy=c.section==="maintenance"&&String(c.reason||"").includes(String(order.orderNo||""));return direct||supplierPurchase||supplierPayment||legacy});
      draft.cash=oldCash.filter(c=>!linked.includes(c));const cashIn=linked.filter(c=>c.type==="in").reduce((n,c)=>n+safeAmount(c.amount),0),cashOut=linked.filter(c=>c.type==="out").reduce((n,c)=>n+safeAmount(c.amount),0);
      if(cashIn>0)draft.cash.push({id:uid(),type:"out",amount:cashIn,section:"maintenance",warehouseId:order.warehouseId||"main",refType:"maintenance-delete-reversal",refId:order.id,customerId:order.customerId||"",reason:"عكس قبض حذف صيانة "+order.orderNo,date:now()});
      if(cashOut>0)draft.cash.push({id:uid(),type:"in",amount:cashOut,section:"supplier",warehouseId:order.warehouseId||"main",refType:"maintenance-delete-reversal",refId:order.id,reason:"عكس صرف حذف صيانة "+order.orderNo,date:now()});
      draft.maintenance=draft.maintenance.filter(v=>String(v.id)!==String(id));commitDraft(state,draft);return {entity:order,audit:{action:"حذف",entity:"صيانة",id:order.id,details:"حذف "+order.orderNo+" | عكس المقبوض والمدفوع: "+cashIn+" / "+cashOut}};
    }
  };window.HassanDomain.maintenanceActions=actions;
})();
