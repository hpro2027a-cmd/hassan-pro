(function(){
  "use strict";
  const {cloneState,commitDraft,assertState,recordInventoryMovement}=window.HassanDomain.helpers;
  const maintenance={
    save(state,input,deps){
      assertState(state); const {uid,now,safeAmount}=deps, draft=cloneState(state), existing=input.existing||null, edit=!!existing;
      const o={...(existing||{}),...input.order,id:existing?.id||uid(),orderNo:existing?.orderNo||("M-"+Date.now())};
      const parts=Array.isArray(input.parts)?input.parts:[];
      if(!o.customerName||!o.customerPhone||!o.model||!o.fault||safeAmount(o.total)<=0) throw new Error("أكمل بيانات العميل والجهاز والعطل وأدخل قيمة صيانة صحيحة");
      if(safeAmount(o.paid)>safeAmount(o.total)) throw new Error("المدفوع لا يمكن أن يتجاوز قيمة الصيانة");
      if(edit){
        for(const oldPart of existing.parts||[]){if(oldPart.source==="warehouse"&&oldPart.productId){const inv=draft.inventory.find(v=>String(v.id)===String(oldPart.productId));if(inv){const q=Number(oldPart.qty||0);inv.qty+=q;recordInventoryMovement(draft,{productId:inv.id,warehouseId:inv.warehouseId,qty:q,direction:"in",sourceType:"maintenance-edit-reversal",sourceId:o.id,reason:"عكس قطع صيانة قديمة"},deps)}}}
        const oldExternalIds=new Set((draft.supplierPurchases||[]).filter(q=>String(q.maintenanceId)===String(o.id)).map(q=>String(q.id)));
        const oldCash=(draft.cash||[]).filter(c=>(["maintenancePartExternal","supplierMaintenancePurchase","supplierPayment"].includes(String(c.refType||"")))&&(String(c.refId||"")===String(o.id)||oldExternalIds.has(String(c.refId||""))||oldExternalIds.has(String(c.supplierPurchaseId||""))));
        const oldOut=oldCash.filter(c=>c.type==="out").reduce((n,c)=>n+safeAmount(c.amount),0);
        draft.supplierPurchases=(draft.supplierPurchases||[]).filter(q=>String(q.maintenanceId)!==String(o.id));
        draft.cash=(draft.cash||[]).filter(c=>!oldCash.includes(c));
        if(oldOut>0)draft.cash.push({id:uid(),type:"in",amount:oldOut,section:"supplier",warehouseId:existing.warehouseId||"main",refType:"maintenance-edit-reversal",refId:o.id,reason:"عكس مدفوعات قطع خارجية قديمة لتعديل صيانة "+o.orderNo,date:now()});
      }
      for(const part of parts){
        if(part.source==="warehouse"){
          const inv=draft.inventory.find(v=>String(v.id)===String(part.productId)&&String(v.warehouseId||"main")===String(o.warehouseId||"main"));
          if(!inv||Number(inv.qty||0)<Number(part.qty||0))throw new Error("الكمية المطلوبة من قطعة الغيار أكبر من المتاح في المخزن");
          inv.qty-=Number(part.qty||0);recordInventoryMovement(draft,{productId:inv.id,warehouseId:inv.warehouseId,qty:Number(part.qty||0),direction:"out",sourceType:"maintenance",sourceId:o.id,reason:"استخدام قطعة في صيانة "+o.orderNo},deps);
        }else{
          const purchase={id:uid(),maintenanceId:o.id,warehouseId:o.warehouseId||"main",supplierId:part.supplierId,supplierName:part.supplierName,name:part.name,qty:part.qty,unitCost:part.unitCost,totalCost:part.totalCost,paid:Number(part.paid||0),due:Number(part.due||0),date:now()};
          draft.supplierPurchases=(draft.supplierPurchases||[]);draft.supplierPurchases.push(purchase);
          if(purchase.paid>0)draft.cash.push({id:uid(),type:"out",amount:purchase.paid,section:"supplier",warehouseId:o.warehouseId||"main",refType:"supplierMaintenancePurchase",refId:purchase.id,maintenanceId:o.id,supplierId:purchase.supplierId,reason:"دفع شراء خارجي لقطعة صيانة "+part.name+" — "+o.orderNo,date:now()});
        }
      }
      if(edit&&existing&&String(existing.warehouseId||"main")!==String(o.warehouseId||"main")){
        draft.cash.forEach(c=>{if((String(c.refType||"")==="maintenance"||String(c.refType||"")==="maintenance-reversal"||String(c.refType||"")==="supplierMaintenancePurchase")&&String(c.refId||"")===String(o.id)||String(c.maintenanceId||"")===String(o.id))c.warehouseId=o.warehouseId||"main"});
        draft.supplierPurchases.forEach(q=>{if(String(q.maintenanceId||"")===String(o.id))q.warehouseId=o.warehouseId||"main"});
      }
      o.parts=parts;o.partsCost=parts.reduce((n,p)=>n+safeAmount(p.totalCost),0);o.status=o.status||"received";o.statusLabel=input.statusLabel||o.status;o.technicianId=String(o.technicianId||"");o.technicianName=String(o.technicianName||"");o.warrantyDays=Math.max(0,Math.floor(Number(o.warrantyDays)||0));o.deliveryDate=String(o.deliveryDate||"");o.updatedAt=now();
      if(edit)draft.maintenance=draft.maintenance.map(v=>String(v.id)===String(o.id)?o:v);else draft.maintenance.unshift(o);
      const delta=safeAmount(o.paid)-safeAmount(existing?.paid);
      if(delta>0)draft.cash.push({id:uid(),type:"in",amount:delta,section:"maintenance",warehouseId:o.warehouseId||"main",refType:"maintenance",refId:o.id,customerId:o.customerId||"",reason:"تحصيل صيانة "+o.orderNo,date:now()});
      if(delta<0)draft.cash.push({id:uid(),type:"out",amount:-delta,section:"maintenance",warehouseId:o.warehouseId||"main",refType:"maintenance",refId:o.id,reason:"عكس تعديل تحصيل صيانة "+o.orderNo,date:now()});
      commitDraft(state,draft);return {entity:o,audit:{action:edit?"تعديل":"إضافة",entity:"صيانة",id:o.id,details:(edit?"تعديل":"استلام")+" أمر "+o.orderNo+" | المخزن "+(o.warehouseId||"main")}};
    }
  };
  window.HassanDomain.maintenance=maintenance;
})();