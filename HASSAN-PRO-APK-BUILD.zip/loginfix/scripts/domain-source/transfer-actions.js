(function(){
  "use strict";
  const {cloneState,commitDraft,assertState,recordInventoryMovement}=window.HassanDomain.helpers;
  const transfers={
    restore(state,id,deps){
      assertState(state);const {uid,now,masterKey}=deps,draft=cloneState(state),transfer=draft.transfers.find(v=>String(v.id)===String(id));if(!transfer||transfer.status==="مسترجع")throw new Error("التحويل غير موجود أو تم استرجاعه بالفعل");
      const qty=Number(transfer.qty||0);if(qty<=0)throw new Error("كمية التحويل غير صالحة");
      let dest=draft.inventory.find(v=>String(v.warehouseId||"main")===String(transfer.toWarehouseId)&&String(v.productMasterId||"")===String(transfer.productMasterId||""));if(!dest&&transfer.productSku)dest=draft.inventory.find(v=>String(v.warehouseId||"main")===String(transfer.toWarehouseId)&&String(v.sku||"")===String(transfer.productSku||""));
      if(!dest)throw new Error("لم يتم العثور على المنتج في المخزن المستلم");if(Number(dest.qty||0)<qty)throw new Error("لا توجد كمية كافية في المخزن المستلم لاسترجاع التحويل");dest.qty=Number(dest.qty||0)-qty;recordInventoryMovement(draft,{productId:dest.id,warehouseId:dest.warehouseId,qty,direction:"out",sourceType:"transfer-restore",sourceId:transfer.id,reason:"عكس تحويل مسترجع"},deps);
      let src=draft.inventory.find(v=>String(v.warehouseId||"main")===String(transfer.fromWarehouseId)&&String(v.productMasterId||"")===String(transfer.productMasterId||""));if(!src&&transfer.productSku)src=draft.inventory.find(v=>String(v.warehouseId||"main")===String(transfer.fromWarehouseId)&&String(v.sku||"")===String(transfer.productSku||""));
      if(!src){src={id:uid(),productMasterId:transfer.productMasterId||masterKey(transfer),name:transfer.productName||"منتج",brand:transfer.productBrand||"",category:transfer.productCategory||"",sku:transfer.productSku||"",warehouseId:transfer.fromWarehouseId,qty:0,minQty:0,cost:0,salePrice:0};draft.inventory.push(src)}
      src.qty=Number(src.qty||0)+qty;recordInventoryMovement(draft,{productId:src.id,warehouseId:src.warehouseId,qty,direction:"in",sourceType:"transfer-restore",sourceId:transfer.id,reason:"إعادة الكمية بعد استرجاع تحويل"},deps);transfer.status="مسترجع";transfer.returnedAt=now();commitDraft(state,draft);return {entity:transfer,audit:{action:"استرجاع تحويل",entity:"مخزون",id:transfer.id,details:"استرجاع "+(transfer.productName||"منتج")+" | النوع: "+(transfer.productCategory||"غير محدد")+" | من "+transfer.fromWarehouseId+" إلى "+transfer.toWarehouseId+" × "+qty}};
    },
    removeRestored(state,id){assertState(state);const draft=cloneState(state),transfer=draft.transfers.find(v=>String(v.id)===String(id));if(!transfer)throw new Error("التحويل غير موجود");if(transfer.status!=="مسترجع")throw new Error("لا يمكن حذف الفاتورة قبل استرجاعها");draft.transfers=draft.transfers.filter(v=>String(v.id)!==String(id));commitDraft(state,draft);return {entity:transfer,audit:{action:"حذف تحويل مسترجع",entity:"مخزون",id:transfer.id,details:"حذف فاتورة التحويل بعد الاسترجاع: "+(transfer.productName||"منتج")}};}
  };window.HassanDomain.transferActions=transfers;
})();
