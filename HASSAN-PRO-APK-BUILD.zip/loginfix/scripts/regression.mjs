import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { join } from 'node:path';

const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '');
const core = readFileSync(join(root, 'scripts', 'domain-source', 'core.js'), 'utf8');

const context = { window: {}, console };
vm.createContext(context);
vm.runInContext(core, context, { filename: 'core.js' });

const domain = context.window.HassanDomain;
if (!domain?.sales?.save) throw new Error('Sales domain is not available');

let sequence = 0;
const deps = {
  uid: () => `test-${++sequence}`,
  now: () => '2026-09-18T09:00:00.000Z',
  safeAmount: value => {
    const n = Number(value);
    return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) / 100 : 0;
  }
};

const state = {
  inventory: [{ id: 'product-1', name: 'Test Product', purchasePrice: 100, cost: 100, salePrice: 150, qty: 2, warehouseId: 'main' }],
  sales: [],
  cash: [],
  customers: [],
  suppliers: [],
  devices: [],
  maintenance: [],
  supplierPurchases: [],
  transfers: []
};

const result = domain.sales.save(state, {
  customerId: '',
  name: 'Test Customer',
  phone: '01000000000',
  address: '',
  productId: 'product-1',
  warehouseId: 'main',
  qty: 1,
  total: 150,
  paid: 150,
  note: ''
}, undefined, deps);

if (state.inventory[0].qty !== 1) throw new Error('Sale did not deduct inventory atomically');
if (state.sales.length !== 1) throw new Error('Sale was not committed to sales');
if (state.sales[0].id !== result.entity.id) throw new Error('Committed sale identity mismatch');
if (state.sales[0].qty !== 1 || state.sales[0].total !== 150 || state.sales[0].paid !== 150) throw new Error('Committed sale fields are inconsistent');
if (state.customers.length !== 1 || state.customers[0].id !== state.sales[0].customerId) throw new Error('Sale customer was not committed atomically');
if (state.cash.length !== 1 || state.cash[0].refType !== 'sale' || state.cash[0].refId !== state.sales[0].id) throw new Error('Sale cash movement was not linked atomically');


const secondResult = domain.sales.save(state, {
  customerId: state.sales[0].customerId,
  name: 'Test Customer',
  phone: '01000000000',
  address: '',
  productId: 'product-1',
  warehouseId: 'main',
  qty: 1,
  total: 150,
  paid: 100,
  note: ''
}, {}, deps);

if (state.inventory[0].qty !== 0) throw new Error('Second sale did not deduct inventory');
if (state.sales.length !== 2) throw new Error('New sale passed as an empty object was not created');
if (state.sales[0].id !== secondResult.entity.id) throw new Error('Second sale identity mismatch');
if (!state.sales[0].no || state.sales[0].no === state.sales[1].no) throw new Error('Sale invoice numbers are not unique');
if (!state.sales[1].id || !state.sales[1].no) throw new Error('First sale lost its identity');

const firstSale = state.sales[1];
const beforeEditCount = state.sales.length;
const editResult = domain.sales.save(state, {
  customerId: firstSale.customerId,
  name: 'Test Customer Edited',
  phone: '01000000000',
  address: 'Edited Address',
  productId: '',
  warehouseId: 'main',
  qty: 1,
  total: 180,
  paid: 180,
  note: 'Edited'
}, firstSale, deps);

if (state.sales.length !== beforeEditCount) throw new Error('Editing a sale duplicated the invoice');
if (state.sales[1].id !== editResult.entity.id || state.sales[1].total !== 180) throw new Error('Existing sale edit was not committed');
if (state.sales[1].no !== firstSale.no) throw new Error('Existing sale number changed during edit');
if (state.inventory[0].qty !== 1) throw new Error('Editing the sale did not restore the sold product quantity');

const beforeInvalid = JSON.stringify(state);
let rejected = false;
try {
  domain.sales.save(state, {
    customerId: '',
    name: 'Invalid Customer',
    phone: '01000000001',
    productId: 'missing-product',
    warehouseId: 'main',
    qty: 1,
    total: 150,
    paid: 150
  }, undefined, deps);
} catch {
  rejected = true;
}
if (!rejected) throw new Error('Invalid sale was accepted');
if (JSON.stringify(state) !== beforeInvalid) throw new Error('Invalid sale partially mutated state');

console.log('Sales regression: PASS');
