import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '');
const indexPath = join(root, 'www', 'index.html');
const sourceDir = join(root, 'scripts', 'domain-source');
const order = [
  'core.js', 'purchases.js', 'warehouses.js', 'cash.js', 'devices.js',
  'maintenance.js', 'customers.js', 'suppliers.js', 'device-actions.js',
  'maintenance-actions.js', 'transfer-actions.js', 'operations.js'
];

const index = readFileSync(indexPath, 'utf8');
const marker = /<script id="hassan-domain-runtime">[\s\S]*?<\/script>/;
const bundle = order.map(file => readFileSync(join(sourceDir, file), 'utf8').trim()).join('\n\n');
const replacement = `<script id="hassan-domain-runtime">\n/* HASSAN PRO DOMAIN BUNDLE — generated from scripts/domain-source/*.js */\n${bundle}\n</script>`;

if (!marker.test(index)) throw new Error('Embedded domain runtime marker not found');
writeFileSync(indexPath, index.replace(marker, replacement));
console.log(`Domain bundle generated from ${order.length} modules.`);
