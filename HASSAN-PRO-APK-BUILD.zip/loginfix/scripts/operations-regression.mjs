import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { join } from 'node:path';

const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '');
const files = ['core.js','operations.js'];
const context = { window: {}, console };
vm.createContext(context);
for (const file of files) vm.runInContext(readFileSync(join(root,'scripts','domain-source',file),'utf8'), context, {filename:file});
const domain=context.window.HassanDomain;
let seq=0;
const deps={uid:()=>`op-${++seq}`,now:()=>`2026-09-18T10:00:0${seq%10}.000Z`,safeAmount:v=>{const n=Number(v);return Number.isFinite(n)&&n>=0?Math.round(n*100)/100:0},masterKey:()=>`mk-${seq}`};
const base=()=>({inventory:[{id:'p1',name:'شاشة',sku:'S1',barcode:'1001',warehouseId:'main',qty:5,minQty:1,cost:100,salePrice:150}],sales:[],cash:[],customers:[],suppliers:[{id:'sup1',name:'مورد',phone:'01000000000'}],devices:[],maintenance:[],supplierPurchases:[{id:'pur1',supplierId:'sup1',supplierName:'مورد',warehouseId:'main',productId:'p1',name:'شاشة',qty:5,unitCost:100,totalCost:500,paid:500,due:0,date:'2026-09-18T09:00:00.000Z'}],transfers:[],audit:[],inventoryMovements:[],salesReturns:[],purchaseReturns:[],cashClosings:[]});

const state=base();
const sale=domain.sales.save(state,{customerId:'',name:'عميل',phone:'01111111111',address:'',productId:'p1',warehouseId:'main',qty:2,total:300,paid:300,note:''},null,deps).entity;
if(state.inventory[0].qty!==3||state.sales.length!==1)throw new Error('sale baseline failed');
const sr=domain.operations.returnSale(state,sale.id,{qty:1,amount:150,refundAmount:150,reason:'اختبار'},deps);
if(state.inventory[0].qty!==4||state.sales[0].returnedQty!==1||state.salesReturns.length!==1||sr.returnRecord.qty!==1)throw new Error('sales return failed');
const pr=domain.operations.returnPurchase(state,'pur1',{qty:1,amount:100,refundAmount:100,reason:'اختبار'},deps);
if(state.inventory[0].qty!==3||state.supplierPurchases[0].returnedQty!==1||state.purchaseReturns.length!==1||pr.returnRecord.qty!==1)throw new Error('purchase return failed');
const close=domain.operations.closeCashDay(state,{warehouseId:'main',date:'2026-09-18',actualBalance:50,note:'اختبار',userId:'manager'},deps);
if(state.cashClosings.length!==1||close.entity.warehouseId!=='main')throw new Error('cash closing failed');
if(state.inventoryMovements.length<3)throw new Error('inventory movement ledger did not record operations');
console.log('Operational regression: PASS');
