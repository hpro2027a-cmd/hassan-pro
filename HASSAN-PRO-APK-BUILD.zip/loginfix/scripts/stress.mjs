import { performance } from 'node:perf_hooks';

const collections=['sales','cash','maintenance','devices','supplierPurchases','transfers'];
const sizes={sales:50000,cash:50000,maintenance:25000,devices:10000,supplierPurchases:25000,transfers:25000};
const state={theme:'dark',sound:true,productTypes:[],productBrands:[],appleCatalog:[]};
for(const key of collections){
  state[key]=Array.from({length:sizes[key]},(_,i)=>({id:`${key}_${i}`,date:`2026-01-${String((i%28)+1).padStart(2,'0')}`,amount:i%1000,total:i%5000,status:'closed'}));
}
const start=performance.now();
const bytes=Buffer.byteLength(JSON.stringify(state));
const elapsed=performance.now()-start;
if(bytes<1024*1024)throw new Error('stress fixture unexpectedly small');
if(bytes>40*1024*1024)throw new Error('stress fixture exceeds intended local stress envelope');
console.log(`Stress fixture: ${(bytes/1024/1024).toFixed(2)} MiB across ${Object.values(sizes).reduce((a,b)=>a+b,0).toLocaleString()} records.`);
console.log(`Full-state serialization benchmark: ${elapsed.toFixed(1)} ms.`);
console.log('Record-sharded persistence does not require this full JSON serialization for ordinary record writes.');
