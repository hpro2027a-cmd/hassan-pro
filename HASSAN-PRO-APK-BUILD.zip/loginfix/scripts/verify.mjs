import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '');
const indexPath = join(root, 'www', 'index.html');
const index = readFileSync(indexPath, 'utf8');

const failures = [];
const checks = [];

function check(name, condition, detail) {
  checks.push({ name, condition });
  if (!condition) failures.push(`${name}: ${detail}`);
}

function collectJsFiles(dir) {
  const files = [];
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const stat = statSync(full);
    if (stat.isDirectory()) files.push(...collectJsFiles(full));
    else if (entry.endsWith('.js') || entry.endsWith('.mjs')) files.push(full);
  }
  return files;
}

const externalScripts = [...index.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi)]
  .map(match => match[1])
  .filter(src => !/^(https?:|\/\/|data:)/i.test(src));

for (const src of externalScripts) {
  const file = join(root, 'www', src.replace(/^\.?\//, ''));
  check(`script exists: ${src}`, statSync(file, { throwIfNoEntry: false })?.isFile() === true, `missing ${file}`);
}

const inlineScripts = [...index.matchAll(/<script\b(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi)]
  .map(match => match[1])
  .filter(source => source.trim());

const sourceFiles = [
  ...collectJsFiles(join(root, 'www')),
  ...inlineScripts.map((_, i) => `__inline_${i}.js`)
];

const inlineDir = join(root, '.verify-inline');
await import('node:fs/promises').then(async fs => {
  await fs.rm(inlineDir, { recursive: true, force: true });
  await fs.mkdir(inlineDir, { recursive: true });
  for (let i = 0; i < inlineScripts.length; i += 1) {
    await fs.writeFile(join(inlineDir, `inline_${i}.js`), inlineScripts[i]);
  }
});

for (const file of collectJsFiles(join(root, 'www')).concat(collectJsFiles(inlineDir))) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  check(`syntax: ${relative(root, file)}`, result.status === 0, result.stderr.trim() || 'node --check failed');
}

const rulesPath = join(root, 'firestore.rules');
const rules = readFileSync(rulesPath, 'utf8');
check('firestore has default deny', /match\s+\/\{document=\*\*\}\s*\{[\s\S]*?allow\s+read,\s+write:\s+if\s+false\s*;/.test(rules), 'default catch-all deny is missing');
check('firestore requires membership for app meta', /match\s+\/companies\/\{companyId\}\/app\/meta[\s\S]*?allow\s+read:\s+if\s+member\(companyId\)/.test(rules), 'tenant membership rule is missing');
check('firestore protects record writes by membership', /match\s+\/companies\/\{companyId\}\/data\/\{collectionName\}\/records\/\{recordId\}[\s\S]*?allow\s+create, update:\s+if\s+member\(companyId\)/.test(rules), 'record membership rule is missing');
check('firestore uses two-phase sync commit', /commitState == 'pending'[\s\S]*?commitState == 'ready'/.test(rules), 'two-phase sync commit rules are missing');

check('no hard-coded legacy admin password', !/admin1234/.test(index), 'legacy master password is present in client code');
check('no client auto-login default', !/localStorage\.getItem\(["']HASSAN_PRO_CURRENT_USER["']\)\s*\|\|\s*["']manager["']/.test(index), 'client still defaults to manager');
check('login uses session storage', /sessionStorage\.getItem\(["']HASSAN_PRO_CURRENT_USER["']\)/.test(index), 'current user is not session-scoped');
check('no runtime domain script dependencies', !externalScripts.some(src => /(^|\/)domain\//i.test(src)), 'runtime still depends on external domain scripts');
check('embedded domain runtime exists', /<script id="hassan-domain-runtime">[\s\S]*?window\.HassanDomain=/.test(index), 'embedded domain runtime is missing or incomplete');
check('new sale passes null when no existing invoice', /HassanDomain\.sales\.save\(state,[\s\S]*?,x\|\|null,\{uid,now,safeAmount\}\)/.test(index), 'sale UI must not convert a new invoice into an empty existing object');
check('domain runtime is self-contained', !/src=\"js\/domain\//.test(index), 'domain modules are still loaded externally');
check('backup package is present', /manifest\.json/.test(index) && /state\.json/.test(index) && /media\//.test(index), 'ZIP backup package markers are missing');
check('data layer executes before embedded domain bundle', /<script>\s*\/\* HASSAN PRO V6\.6/.test(index) && index.indexOf('HASSAN PRO V6.5') < index.indexOf('<script id="hassan-domain-runtime">'), 'data layer must execute before embedded domain runtime');
check('data layer is classic script for deterministic ordering', !/<script type="module">\s*\/\* HASSAN PRO V6\.[35]/.test(index), 'data layer is still a deferred module and can race domain scripts');
check('local data uses IndexedDB', /indexedDB\.open/.test(index) && /HASSAN_PRO_DATA_V63/.test(index) && /DB_VERSION=3/.test(index), 'IndexedDB data store or schema upgrade is missing');
check('Firestore uses record collections', /companies',company\(\),'data',key,'records'/.test(index), 'record-level Firestore path is missing');
check('state schema is version 4', /const STATE_SCHEMA_VERSION=4/.test(index), 'state schema version was not raised to the operational hardening schema');
check('app version is 6.6.0', /const APP_VERSION="6\.6\.0"/.test(index), 'app version was not raised to the operational hardening build');
check('factory reset backup is optional', !/يجب إنشاء نسخة احتياطية ناجحة قبل السماح بالضبط/.test(index) && !/if\(!backupReady\)\{toast\("يجب إنشاء نسخة احتياطية ناجحة أولًا"/.test(index), 'factory reset still blocks execution without backup');
check('factory reset has explicit destructive acknowledgement', /resetAcknowledge/.test(index) && /resetSectionAck/.test(index), 'destructive reset acknowledgement is missing');
check('factory reset supports cloud reset', /resetCloudToState/.test(index) && /factory-reset/.test(index), 'cloud reset operation is missing');
check('factory reset supports local-only reset', /preserveCloudAndResetLocal/.test(index) && /LOCAL_RESET_CLOUD_PRESERVED/.test(index), 'local-only reset preservation mode is missing');
check('local-only reset blocks automatic cloud restore', /if\(isLocalResetCloudPreserved\(\)\)\{ready=false;return false\}/.test(index), 'local-only reset can be overwritten by automatic cloud setup');
check('explicit cloud pull clears local-only preservation', /if\(force\)clearLocalResetPreservation\(\)/.test(index), 'explicit cloud import cannot resume after local-only reset');
check('factory reset requires manager for cloud operation', /manager-required/.test(index) && /membership/.test(index) && /role/.test(index), 'cloud reset lacks client-side manager guard');
check('inventory movement ledger exists', /inventoryMovements/.test(index) && /recordInventoryMovement/.test(index), 'inventory movement ledger is missing');
check('sales return operation exists', /returnSale\(state,saleId/.test(index) && /salesReturns/.test(index), 'sales return operation is missing');
check('purchase return operation exists', /returnPurchase\(state,purchaseId/.test(index) && /purchaseReturns/.test(index), 'purchase return operation is missing');
check('cash closing operation exists', /closeCashDay\(state,input/.test(index) && /cashClosings/.test(index), 'cash closing operation is missing');
check('audit is not capped at 1000', !/state\.audit\.length>1000/.test(index), 'audit history is still capped at 1000 records');
check('device identity uniqueness covers IMEI', /IMEI مستخدم بالفعل في جهاز آخر/.test(index), 'IMEI uniqueness guard is missing');
check('old monolithic Firestore state field is removed', !/transaction\.set\(ref/.test(index) && !/remote\?\.state/.test(index), 'legacy monolithic Firestore state write remains');
check('historical entities are lazy at startup', /LAZY_ENTITY_KEYS=new Set\(\['sales','maintenance','devices','cash','transfers','customers','suppliers','audit'/.test(index) && /LAZY_ENTITY_KEYS\.forEach\(key=>\{result\[key\]=\[\]\}\)/.test(index), 'historical entities are still hydrated during startup');
check('IndexedDB query-on-demand API exists', /window\.hassanLocalQuery=/.test(index) && /localQueryRequest/.test(index) && /openCursor/.test(index), 'query-on-demand IndexedDB layer is missing');
check('no collection-wide realtime listeners', !/onSnapshot\(collectionRef\(key\)/.test(index), 'historical Firestore collections still have collection-wide realtime listeners');
check('external cloud revisions do not auto-hydrate history', /يوجد تحديث سحابي أحدث\. افتح المزامنة واختر الاستيراد يدويًا/.test(index), 'external cloud revisions still trigger full remote hydration');


await import('node:fs/promises').then(fs => fs.rm(inlineDir, { recursive: true, force: true }));

const regression = spawnSync(process.execPath, [join(root, 'scripts', 'operations-regression.mjs')], { encoding: 'utf8' });
check('operational regression suite', regression.status === 0, regression.stderr.trim() || regression.stdout.trim() || 'operational regression failed');

const passed = checks.filter(item => item.condition).length;
console.log(`Verification: ${passed}/${checks.length} checks passed.`);
if (failures.length) {
  console.error(failures.map(item => `- ${item}`).join('\n'));
  process.exitCode = 1;
}
