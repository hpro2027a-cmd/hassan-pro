# تحويل HASSAN PRO إلى APK من الموبايل

هذا المشروع مجهز بالفعل بـ Capacitor، والملف `www/index.html` هو واجهة التطبيق.

## الطريقة بدون كمبيوتر

1. ارفع محتويات هذا المشروع إلى مستودع GitHub جديد.
2. افتح تبويب **Actions** في المستودع.
3. اختر **Build HASSAN PRO APK**.
4. اضغط **Run workflow**.
5. بعد انتهاء البناء افتح نتيجة الـ workflow وحمّل artifact باسم:
   `HASSAN-PRO-debug-apk`
6. فك ضغط الـ artifact وستجد `app-debug.apk`.

الـ APK الناتج Debug ومناسب للتثبيت والاختبار على الهاتف. للنشر على Google Play نحتاج لاحقًا إنشاء Release موقّع بمفتاح توقيع خاص.
